#!/bin/zsh
set -e

cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "未找到 Python 3。请先安装 Python 3，再重新打开。"
  read -r "?按回车关闭窗口。"
  exit 1
fi

if ! python3 -c "import pypdf" >/dev/null 2>&1; then
  echo "首次使用需要安装 Python 依赖。请先在当前文件夹执行："
  echo "python3 -m pip install -r requirements.txt"
  read -r "?按回车关闭窗口。"
  exit 1
fi

python3 "工作台文件/xiaoye_workbench.py" --open
