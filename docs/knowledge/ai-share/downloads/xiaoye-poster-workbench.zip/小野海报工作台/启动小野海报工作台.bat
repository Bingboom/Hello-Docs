@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
  set "XIAOYE_PYTHON=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo 未找到 Python 3。请先安装 Python 3，再重新打开。
    pause
    exit /b 1
  )
  set "XIAOYE_PYTHON=python"
)

%XIAOYE_PYTHON% -c "import pypdf" >nul 2>nul
if errorlevel 1 (
  echo 首次使用需要安装 Python 依赖。请先在当前文件夹执行：
  echo %XIAOYE_PYTHON% -m pip install -r requirements.txt
  pause
  exit /b 1
)

%XIAOYE_PYTHON% "工作台文件\xiaoye_workbench.py" --open
if errorlevel 1 pause
