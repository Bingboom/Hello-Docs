# 小野海报本地工作台使用说明

这套工作台只在本机运行，不会自动上传文件，也不会连接钉钉或 GitHub。

日常使用只需要保留这个完整文件夹。macOS 双击“`启动小野海报工作台.command`”，Windows 双击“`启动小野海报工作台.bat`”。“`工作台文件`”里是程序、资料、图片和生成结果，不需要逐个打开或移动。

本机需要 Python 3、Node.js 22 或更高版本，以及 Google Chrome、Microsoft Edge 或 Chromium。浏览器负责按照现有 HTML 和打印样式导出 PDF 与 PNG。

第一次使用时，在这个文件夹里安装 Python 依赖：

```bash
python3 -m pip install -r requirements.txt
```

## macOS 启动

安装依赖后，可以直接双击“`启动小野海报工作台.command`”。如果系统阻止首次打开，按住 Control 点击该文件，选择“打开”。

也可以打开“终端”，先进入“`小野海报工作台`”文件夹，再手动启动：

```bash
cd "/path/to/小野海报工作台"
python3 "工作台文件/xiaoye_workbench.py" --open
```

其中 `/path/to/` 要换成实际保存位置。也可以在终端输入 `cd `（末尾保留一个空格），把“`小野海报工作台`”文件夹拖进终端窗口，再按回车。

工作台页面是：<http://127.0.0.1:62100/workbench>

启动后不要关闭运行服务的终端窗口。

## Windows 启动

第一次使用时，在文件夹空白处按住 Shift 点击鼠标右键，选择“在终端中打开”，执行：

```powershell
py -3 -m pip install -r requirements.txt
```

以后双击“`启动小野海报工作台.bat`”即可。如果电脑没有 `py` 命令，启动脚本会自动尝试 `python`。

Windows 版会依次查找 Chrome、Edge 和 Chromium。使用过程中不要关闭打开的命令提示符窗口。

## 修改资料

目前工作台页面只支持修改每款产品的“教学价”。输入新价格并点击该款的“保存”即可；其他名称、容量、输出、重量、标题和介绍暂时不能在页面中修改。

数据源文件都在“`工作台文件`”目录：

- `xiaoye-poster-products.csv`：型号、名称、容量、额定输出、重量、教学价和图片文件名。
- `xiaoye-poster-content.csv`：型号、标题和介绍模板。

两张表按 `model` 型号关联，不按行号匹配。除教学价外，如果要修改其他字段，需要人工编辑对应 CSV，并另行运行、检查生成流程；当前工作台不会自动监听手工修改的 CSV。

## 图片放置位置

把三款 PNG 插画放在“`工作台文件`”目录，也就是与 `xiaoye_workbench.py` 相同的文件夹。当前文件名为：

- `xiaoye-300.png`
- `xiaoye-500.png`
- `xiaoye-1000.png`

文件名还必须与 `xiaoye-poster-products.csv` 中对应型号的 `image_filename` 一致。缺图片、图片不是 PNG 或型号对应不上时，程序会报错，不会猜测路径。

## 保存价格后自动完成的内容

点击某一款的“保存”后，程序会自动：

1. 检查价格是大于 0 的数字。
2. 把价格写回 `xiaoye-poster-products.csv`。
3. 只为这一款重新生成 HTML。
4. 使用本机已有的 Google Chrome，从同一份 HTML 和打印样式导出单页 A5 PDF 与 PNG。
5. 核对 HTML、PDF、PNG 均成功后，再更新该款的成功版本和最后更新时间。

另外两款的 HTML、PDF、PNG、成功版本和最后更新时间不会随之更新。

## 仍需手动完成的内容

- 启动和停止本地服务。
- 输入价格并点击“保存”。
- 使用“打开海报”“下载 PDF”或“打开 PNG”查看成品。
- 需要纸张或系统打印设置时，使用“打印 / 保存 PDF”并在浏览器对话框中手动选择。
- 最终视觉确认、对外发送、上传、Git 提交和 GitHub 推送。

目前没有自动上传、自动打印、批量打包、版本回退或 GitHub 同步功能。

## 输出文件位置

所有输出都保存在“`工作台文件`”目录：

- 小野 300：`xiaoye-300-poster.html`、`xiaoye-300-poster.pdf`、`xiaoye-300-poster.png`
- 小野 500：`xiaoye-500-poster.html`、`xiaoye-500-poster.pdf`、`xiaoye-500-poster.png`
- 小野 1000：`xiaoye-1000-poster.html`、`xiaoye-1000-poster.pdf`、`xiaoye-1000-poster.png`

## 出现错误时

先看工作台顶部的运行状态，再看对应产品卡片中的“本次改动”和红色失败原因。失败原因会指出是 HTML 生成、PDF 导出、PDF 核对、PNG 导出、PNG 核对还是文件提交失败。

同时查看启动服务的终端窗口，那里会显示访问和服务错误记录。常见检查项包括：

- 教学价是否为大于 0 的数字。
- 产品表和内容表是否缺字段、缺型号或型号不一致。
- 图片是否位于项目根目录，文件名是否与产品表一致。
- Google Chrome 是否仍安装在本机。
- Node.js 是否仍可用。

如果资料已保存但导出失败，工作台会明确显示“资料已保存”，并保留上一版成功的 HTML、PDF 和 PNG。修正问题后，可以保持当前价格不变，再点击一次“保存”重试。

## 停止服务

回到启动工作台的终端或命令提示符窗口，按 `Control-C`。看到“工作台已停止”后即可关闭窗口。
