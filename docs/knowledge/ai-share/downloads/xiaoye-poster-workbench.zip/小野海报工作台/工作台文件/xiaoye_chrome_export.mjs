#!/usr/bin/env node

import { writeFile } from "node:fs/promises";

const [webSocketUrl, sourceUrl, pdfPath, pngPath] = process.argv.slice(2);

if (!webSocketUrl || !sourceUrl || !pdfPath || !pngPath) {
  process.stderr.write(JSON.stringify({
    step: "浏览器导出",
    detail: "缺少 WebSocket、源页面或输出路径",
  }));
  process.exit(2);
}

class StepError extends Error {
  constructor(step, detail) {
    super(detail);
    this.step = step;
    this.detail = detail;
  }
}

const socket = new WebSocket(webSocketUrl);
let nextId = 1;
const pending = new Map();
const eventWaiters = new Map();

function waitForOpen() {
  return new Promise((resolve, reject) => {
    socket.addEventListener("open", resolve, { once: true });
    socket.addEventListener("error", () => reject(new Error("无法连接 Chrome 调试接口")), { once: true });
  });
}

function command(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    socket.send(JSON.stringify({ id, method, params }));
  });
}

function waitForEvent(method) {
  return new Promise((resolve) => {
    const waiters = eventWaiters.get(method) || [];
    waiters.push(resolve);
    eventWaiters.set(method, waiters);
  });
}

socket.addEventListener("message", (event) => {
  const message = JSON.parse(event.data);
  if (message.id) {
    const promise = pending.get(message.id);
    if (!promise) return;
    pending.delete(message.id);
    if (message.error) {
      promise.reject(new Error(message.error.message || "Chrome 命令失败"));
    } else {
      promise.resolve(message.result || {});
    }
    return;
  }
  if (message.method) {
    const waiters = eventWaiters.get(message.method) || [];
    eventWaiters.delete(message.method);
    for (const resolve of waiters) resolve(message.params || {});
  }
});

async function atStep(step, operation) {
  try {
    return await operation();
  } catch (error) {
    throw new StepError(step, error?.message || String(error));
  }
}

async function main() {
  await atStep("浏览器启动", waitForOpen);
  await atStep("页面载入", async () => {
    await command("Page.enable");
    await command("Runtime.enable");
    await command("Emulation.setDeviceMetricsOverride", {
      width: 600,
      height: 850,
      deviceScaleFactor: 1,
      mobile: false,
    });
    const loaded = waitForEvent("Page.loadEventFired");
    await command("Page.navigate", { url: sourceUrl });
    await loaded;
    const ready = await command("Runtime.evaluate", {
      expression: `
        (async () => {
          await document.fonts.ready;
          await Promise.all(Array.from(document.images).map((image) => {
            if (image.complete && image.naturalWidth > 0) return Promise.resolve();
            return new Promise((resolve, reject) => {
              image.addEventListener("load", resolve, { once: true });
              image.addEventListener("error", () => reject(new Error("图片载入失败")), { once: true });
            });
          }));
          const poster = document.querySelector(".poster");
          if (!poster) throw new Error("页面缺少 .poster 元素");
          const rect = poster.getBoundingClientRect();
          return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
        })()
      `,
      awaitPromise: true,
      returnByValue: true,
    });
    if (ready.exceptionDetails) {
      throw new Error(ready.exceptionDetails.text || "页面资源载入失败");
    }
    globalThis.posterRect = ready.result.value;
  });

  await atStep("PDF 导出", async () => {
    const result = await command("Page.printToPDF", {
      landscape: false,
      displayHeaderFooter: false,
      printBackground: true,
      preferCSSPageSize: true,
      marginTop: 0,
      marginBottom: 0,
      marginLeft: 0,
      marginRight: 0,
      transferMode: "ReturnAsBase64",
    });
    await writeFile(pdfPath, Buffer.from(result.data, "base64"));
  });

  await atStep("PNG 导出", async () => {
    const rect = globalThis.posterRect;
    const result = await command("Page.captureScreenshot", {
      format: "png",
      fromSurface: true,
      captureBeyondViewport: true,
      clip: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        scale: 2,
      },
    });
    await writeFile(pngPath, Buffer.from(result.data, "base64"));
  });
}

try {
  await main();
  socket.close();
} catch (error) {
  socket.close();
  process.stderr.write(JSON.stringify({
    step: error.step || "浏览器导出",
    detail: error.detail || error.message || String(error),
  }));
  process.exit(1);
}
