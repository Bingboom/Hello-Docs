#!/usr/bin/env python3
"""Generate the three fictional Xiaoye A5 posters from model-keyed CSV data."""

from __future__ import annotations

import argparse
import csv
import html
import re
import string
import sys
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple


ROOT = Path(__file__).resolve().parent
PRODUCTS_CSV = ROOT / "xiaoye-poster-products.csv"
CONTENT_CSV = ROOT / "xiaoye-poster-content.csv"
TEMPLATE_DIR = ROOT / "xiaoye-poster-templates"

PRODUCT_FIELDS = (
    "model",
    "name",
    "capacity_wh",
    "rated_output_w",
    "weight_kg",
    "teaching_price_cny",
    "image_filename",
)
CONTENT_FIELDS = ("model", "title", "intro_template")
NUMERIC_FIELDS = (
    "capacity_wh",
    "rated_output_w",
    "weight_kg",
    "teaching_price_cny",
)
INTEGER_FIELDS = ("capacity_wh", "rated_output_w", "teaching_price_cny")
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
TOKEN_RE = re.compile(r"\{\{([a-z][a-z0-9_]*)\}\}")

LAYOUTS = {
    "DEMO-300": (
        TEMPLATE_DIR / "DEMO-300.html.tpl",
        ROOT / "xiaoye-300-poster.html",
    ),
    "DEMO-500": (
        TEMPLATE_DIR / "DEMO-500.html.tpl",
        ROOT / "xiaoye-500-poster.html",
    ),
    "DEMO-1000": (
        TEMPLATE_DIR / "DEMO-1000.html.tpl",
        ROOT / "xiaoye-1000-poster.html",
    ),
}


class ValidationError(Exception):
    """Raised when source data cannot safely generate the posters."""

    def __init__(self, issues: Sequence[str]) -> None:
        super().__init__("; ".join(issues))
        self.issues = list(issues)


@dataclass(frozen=True)
class Product:
    model: str
    name: str
    capacity_wh: str
    rated_output_w: str
    weight_kg: str
    teaching_price_cny: str
    image_filename: str

    @classmethod
    def from_row(cls, row: Mapping[str, str]) -> "Product":
        return cls(**{field: row[field] for field in PRODUCT_FIELDS})

    def as_format_values(self) -> Dict[str, str]:
        return {field: getattr(self, field) for field in PRODUCT_FIELDS}


@dataclass(frozen=True)
class Content:
    model: str
    title: str
    intro_template: str

    @classmethod
    def from_row(cls, row: Mapping[str, str]) -> "Content":
        return cls(**{field: row[field] for field in CONTENT_FIELDS})


def read_keyed_csv(
    path: Path,
    required_fields: Sequence[str],
) -> Tuple[Dict[str, Dict[str, str]], List[str]]:
    issues: List[str] = []
    rows: Dict[str, Dict[str, str]] = {}
    if not path.is_file():
        return rows, [f"缺少数据表：{path.name}"]

    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
        missing = [field for field in required_fields if field not in fieldnames]
        if missing:
            issues.append(f"{path.name} 缺少字段：{', '.join(missing)}")
            return rows, issues

        for line_number, raw_row in enumerate(reader, start=2):
            row = {
                field: (raw_row.get(field) or "").strip()
                for field in required_fields
            }
            model = row["model"]
            if not model:
                issues.append(f"{path.name} 第 {line_number} 行缺少 model")
                continue
            blank_fields = [field for field, value in row.items() if not value]
            if blank_fields:
                issues.append(
                    f"{path.name} 型号 {model} 缺少字段值："
                    f"{', '.join(blank_fields)}"
                )
            if model in rows:
                issues.append(f"{path.name} 型号重复：{model}")
                continue
            rows[model] = row

    return rows, issues


def validate_positive_number(model: str, field: str, value: str) -> List[str]:
    try:
        number = Decimal(value)
    except InvalidOperation:
        return [f"产品表型号 {model} 的 {field} 不是有效数字：{value}"]
    if number <= 0:
        return [f"产品表型号 {model} 的 {field} 必须大于 0：{value}"]
    if field in INTEGER_FIELDS and number != number.to_integral_value():
        return [f"产品表型号 {model} 的 {field} 必须是整数：{value}"]
    return []


def intro_placeholders(template: str) -> Tuple[set[str], List[str]]:
    placeholders: set[str] = set()
    issues: List[str] = []
    formatter = string.Formatter()
    try:
        parsed = formatter.parse(template)
        for _, field_name, _, _ in parsed:
            if field_name is None:
                continue
            if not re.fullmatch(r"[a-z][a-z0-9_]*", field_name):
                issues.append(f"介绍模板含不支持的占位符：{field_name}")
                continue
            placeholders.add(field_name)
    except ValueError as exc:
        issues.append(f"介绍模板花括号格式错误：{exc}")
    return placeholders, issues


def validate_sources(
    product_rows: Mapping[str, Mapping[str, str]],
    content_rows: Mapping[str, Mapping[str, str]],
) -> Tuple[Dict[str, Product], Dict[str, Content]]:
    issues: List[str] = []
    products = {
        model: Product.from_row(row) for model, row in product_rows.items()
    }
    contents = {
        model: Content.from_row(row) for model, row in content_rows.items()
    }

    product_models = set(products)
    content_models = set(contents)
    layout_models = set(LAYOUTS)
    for model in sorted(product_models - content_models):
        issues.append(f"型号 {model} 在产品表中存在，但内容表缺失")
    for model in sorted(content_models - product_models):
        issues.append(f"型号 {model} 在内容表中存在，但产品表缺失")
    for model in sorted(layout_models - product_models):
        issues.append(f"海报布局 {model} 缺少产品表记录")
    for model in sorted(product_models - layout_models):
        issues.append(f"型号 {model} 没有对应的海报布局模板")

    allowed_placeholders = set(PRODUCT_FIELDS)
    for model, product in products.items():
        for field in NUMERIC_FIELDS:
            issues.extend(
                validate_positive_number(model, field, getattr(product, field))
            )

        model_suffix = model.rsplit("-", 1)[-1]
        expected_image = f"xiaoye-{model_suffix}.png"
        if product.image_filename != expected_image:
            issues.append(
                f"型号 {model} 的图片文件名不匹配："
                f"表中为 {product.image_filename}，应为 {expected_image}"
            )
        image_path = ROOT / product.image_filename
        if not image_path.is_file():
            issues.append(
                f"型号 {model} 缺少图片：{product.image_filename}"
            )
        elif image_path.read_bytes()[:8] != PNG_SIGNATURE:
            issues.append(
                f"型号 {model} 的图片不是有效 PNG：{product.image_filename}"
            )

        name_parts = product.name.rsplit(" ", 1)
        if len(name_parts) != 2 or name_parts[1] != model_suffix:
            issues.append(
                f"型号 {model} 与名称不匹配：{product.name}"
            )

        content = contents.get(model)
        if content is None:
            continue
        placeholders, template_issues = intro_placeholders(content.intro_template)
        issues.extend(f"内容表型号 {model}：{issue}" for issue in template_issues)
        unknown = sorted(placeholders - allowed_placeholders)
        if unknown:
            issues.append(
                f"内容表型号 {model} 使用未知占位符：{', '.join(unknown)}"
            )
        if "name" not in placeholders:
            issues.append(f"内容表型号 {model} 的介绍模板未引用 {{name}}")

        hardcoded_values = (
            product.name,
            f"{product.capacity_wh} Wh",
            f"{product.rated_output_w} W",
            f"{product.weight_kg} kg",
        )
        for literal in hardcoded_values:
            if literal in content.intro_template:
                issues.append(
                    f"内容表型号 {model} 的介绍模板硬编码了产品值：{literal}"
                )

    for model, (template_path, _) in LAYOUTS.items():
        if not template_path.is_file():
            issues.append(f"型号 {model} 缺少布局模板：{template_path.name}")

    if issues:
        raise ValidationError(issues)
    return products, contents


def split_title(title: str, model: str) -> Tuple[str, str, str]:
    mark = "。" if title.endswith("。") else ""
    core = title[:-1] if mark else title
    split_at = core.find("的")
    if split_at < 1 or split_at == len(core) - 1:
        raise ValidationError(
            [f"内容表型号 {model} 的标题无法按现有两行布局拆分：{title}"]
        )
    return core[: split_at + 1], core[split_at + 1 :], mark


def split_intro(intro: str, model: str) -> Tuple[str, str]:
    split_at = intro.find("。")
    if split_at < 0 or split_at == len(intro) - 1:
        raise ValidationError(
            [f"内容表型号 {model} 的介绍必须包含前导句和正文：{intro}"]
        )
    return intro[: split_at + 1], intro[split_at + 1 :]


def replace_layout_tokens(
    template: str,
    values: Mapping[str, str],
    model: str,
) -> str:
    required_tokens = set(TOKEN_RE.findall(template))
    missing = sorted(required_tokens - set(values))
    if missing:
        raise ValidationError(
            [f"型号 {model} 的布局缺少生成值：{', '.join(missing)}"]
        )
    rendered = template
    for token in required_tokens:
        rendered = rendered.replace(f"{{{{{token}}}}}", values[token])
    unresolved = sorted(set(TOKEN_RE.findall(rendered)))
    if unresolved:
        raise ValidationError(
            [f"型号 {model} 的布局仍有未替换值：{', '.join(unresolved)}"]
        )
    return rendered


def render_poster(product: Product, content: Content, template_path: Path) -> str:
    format_values = product.as_format_values()
    try:
        intro = content.intro_template.format_map(format_values)
    except KeyError as exc:
        raise ValidationError(
            [f"内容表型号 {product.model} 缺少模板值：{exc.args[0]}"]
        ) from exc

    title_line1, title_line2, title_mark = split_title(
        content.title, product.model
    )
    intro_lead, intro_detail = split_intro(intro, product.model)
    product_prefix, product_number = product.name.rsplit(" ", 1)

    raw_values = {
        **format_values,
        "title_line1": title_line1,
        "title_line2": title_line2,
        "title_mark": title_mark,
        "intro_lead": intro_lead,
        "intro_detail": intro_detail,
        "product_prefix": product_prefix,
        "product_number": product_number,
    }
    escaped_values = {
        key: html.escape(value, quote=True) for key, value in raw_values.items()
    }
    template = template_path.read_text(encoding="utf-8")
    return replace_layout_tokens(template, escaped_values, product.model)


def build_outputs() -> Dict[str, Tuple[Product, Path, str]]:
    product_rows, product_issues = read_keyed_csv(PRODUCTS_CSV, PRODUCT_FIELDS)
    content_rows, content_issues = read_keyed_csv(CONTENT_CSV, CONTENT_FIELDS)
    issues = product_issues + content_issues
    if issues:
        raise ValidationError(issues)
    products, contents = validate_sources(product_rows, content_rows)

    outputs: Dict[str, Tuple[Product, Path, str]] = {}
    for model, (template_path, output_path) in LAYOUTS.items():
        product = products[model]
        rendered = render_poster(product, contents[model], template_path)
        outputs[model] = (product, output_path, rendered)
    return outputs


def write_outputs(outputs: Mapping[str, Tuple[Product, Path, str]]) -> None:
    for _, output_path, rendered in outputs.values():
        output_path.write_text(rendered, encoding="utf-8")


def check_outputs(outputs: Mapping[str, Tuple[Product, Path, str]]) -> List[str]:
    stale: List[str] = []
    for model, (_, output_path, rendered) in outputs.items():
        if not output_path.is_file():
            stale.append(f"型号 {model} 缺少生成文件：{output_path.name}")
            continue
        if output_path.read_text(encoding="utf-8") != rendered:
            stale.append(f"型号 {model} 的生成文件不是最新：{output_path.name}")
    return stale


def print_summary(
    outputs: Mapping[str, Tuple[Product, Path, str]],
    heading: str,
) -> None:
    print(heading)
    for model, (product, output_path, _) in outputs.items():
        print(
            f"- {model} -> {output_path.name} "
            f"(图片 {product.image_filename})"
        )


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="从两张 CSV 表生成三张小野教学海报。"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="只检查数据、图片和生成结果是否一致，不写文件。",
    )
    return parser.parse_args(list(argv))


def main(argv: Iterable[str] = ()) -> int:
    args = parse_args(argv)
    try:
        outputs = build_outputs()
        if args.check:
            stale = check_outputs(outputs)
            if stale:
                raise ValidationError(stale)
            print_summary(outputs, "检查通过：三张海报与两张表一致。")
            return 0
        write_outputs(outputs)
        print_summary(outputs, "生成完成：已更新三张 HTML 海报。")
        return 0
    except ValidationError as exc:
        print("生成失败：", file=sys.stderr)
        for issue in exc.issues:
            print(f"- {issue}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
