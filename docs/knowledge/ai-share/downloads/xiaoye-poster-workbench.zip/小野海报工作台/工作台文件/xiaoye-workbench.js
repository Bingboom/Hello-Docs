"use strict";

const grid = document.querySelector("#poster-grid");
const overallStatus = document.querySelector("#overall-status");
const runtimeTime = document.querySelector("#runtime-time");
const globalMessage = document.querySelector("#global-message");
const cards = new Map();

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(date);
}

function showGlobalMessage(message, isError = false) {
  globalMessage.hidden = !message;
  globalMessage.textContent = message || "";
  globalMessage.classList.toggle("is-error", isError);
}

function setOverallStatus(payload) {
  overallStatus.className = "status-pill";
  if (payload.overall_status === "warning") {
    overallStatus.classList.add("is-warning");
  }
  overallStatus.querySelector(".status-text").textContent = payload.overall_message;
  runtimeTime.textContent = `本次服务启动：${formatTime(payload.started_at)}`;
}

function cardMarkup(product) {
  const failed = product.status === "failed" || !product.in_sync;
  const failure = product.failure_reason
    ? `<span class="failure-reason">失败原因：${escapeHtml(product.failure_reason)}</span>`
    : "";
  return `
    <article class="poster-card" data-model="${escapeHtml(product.model)}">
      <header class="card-header">
        <div class="card-title-wrap">
          <span class="card-model">${escapeHtml(product.model)}</span>
          <h3 class="card-title">${escapeHtml(product.name)}</h3>
        </div>
        <span class="card-status${failed ? " is-failed" : ""}">
          ${failed ? "更新失败" : "海报正常"}
        </span>
      </header>

      <div class="preview-frame">
        <img
          class="export-preview"
          src="${escapeHtml(product.png_url)}?preview=${Date.now()}"
          alt="${escapeHtml(product.name)} 自动导出的 PNG 海报预览"
        >
        <span class="preview-badge">PNG 预览</span>
      </div>

      <div class="card-body">
        <div class="metadata-grid">
          <div class="metadata-item">
            <span class="metadata-label">当前教学价</span>
            <strong class="metadata-value current-price">¥ ${escapeHtml(product.price)} 元</strong>
          </div>
          <div class="metadata-item">
            <span class="metadata-label">成功版本</span>
            <strong class="metadata-value version-value">v${escapeHtml(product.successful_version)}</strong>
          </div>
          <div class="metadata-item">
            <span class="metadata-label">最后成功更新</span>
            <strong class="metadata-value update-time">${escapeHtml(formatTime(product.last_success_at))}</strong>
          </div>
          <div class="metadata-item">
            <span class="metadata-label">成功海报价格</span>
            <strong class="metadata-value success-price">¥ ${escapeHtml(product.last_success_price)} 元</strong>
          </div>
        </div>

        <div class="change-block${failed ? " is-failed" : ""}">
          <span class="change-title">本次改动</span>
          <p class="change-copy">${escapeHtml(product.last_change)}${failure}</p>
        </div>

        <form class="price-form" novalidate>
          <label class="price-label" for="price-${escapeHtml(product.model)}">修改教学价</label>
          <div class="price-controls">
            <div class="price-input-wrap">
              <span class="currency">¥</span>
              <input
                class="price-input"
                id="price-${escapeHtml(product.model)}"
                name="price"
                type="number"
                inputmode="decimal"
                step="any"
                value="${escapeHtml(product.price)}"
                aria-describedby="message-${escapeHtml(product.model)}"
              >
              <span class="price-suffix">元</span>
            </div>
            <button class="save-button" type="submit">保存</button>
          </div>
          <p class="form-message" id="message-${escapeHtml(product.model)}" aria-live="polite"></p>
        </form>

        <div class="card-actions">
          <a class="action-link" href="${escapeHtml(product.poster_url)}" target="_blank" rel="noopener">打开海报</a>
          <a class="action-link" href="${escapeHtml(product.pdf_url)}" download>下载 PDF</a>
          <a class="action-link" href="${escapeHtml(product.png_url)}" target="_blank" rel="noopener">打开 PNG</a>
          <button class="print-button" type="button">打印 / 保存 PDF</button>
        </div>
      </div>
    </article>
  `;
}

function wireCard(card, product) {
  const form = card.querySelector(".price-form");
  const input = card.querySelector(".price-input");
  const saveButton = card.querySelector(".save-button");
  const message = card.querySelector(".form-message");
  const printButton = card.querySelector(".print-button");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    message.className = "form-message";
    const rawPrice = input.value.trim();
    const numericPrice = Number(rawPrice);
    if (!rawPrice || !Number.isFinite(numericPrice) || numericPrice <= 0) {
      message.textContent = "未保存：教学价必须是大于 0 的数字。";
      message.classList.add("is-error");
      input.focus();
      return;
    }

    saveButton.disabled = true;
    input.disabled = true;
    message.textContent = "正在保存资料并更新这一款 HTML、PDF 和 PNG…";
    try {
      const response = await fetch(`/api/products/${encodeURIComponent(product.model)}/price`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ price: rawPrice }),
      });
      const result = await response.json();
      const displayMessage = result.message || result.error || "保存失败。";
      message.textContent = displayMessage;
      message.classList.add(response.ok ? "is-success" : "is-error");
      await loadStatus({
        preserveMessages: true,
        refreshModel: result.poster_updated ? product.model : null,
      });
    } catch (error) {
      message.textContent = `保存失败：${error.message}`;
      message.classList.add("is-error");
    } finally {
      saveButton.disabled = false;
      input.disabled = false;
    }
  });

  printButton.addEventListener("click", () => {
    const printWindow = window.open(`${product.poster_url}?print=${Date.now()}`, "_blank");
    if (!printWindow) {
      message.textContent = "浏览器阻止了新窗口，请先允许弹窗后再试。";
      message.className = "form-message is-error";
      return;
    }
    printWindow.addEventListener(
      "load",
      () => {
        printWindow.focus();
        printWindow.print();
      },
      { once: true },
    );
  });
}

function renderProducts(products, options = {}) {
  const previousMessages = new Map();
  if (options.preserveMessages) {
    for (const [model, card] of cards) {
      previousMessages.set(model, {
        text: card.querySelector(".form-message")?.textContent || "",
        className: card.querySelector(".form-message")?.className || "form-message",
      });
    }
  }

  grid.innerHTML = products.map(cardMarkup).join("");
  cards.clear();
  for (const product of products) {
    const card = grid.querySelector(`[data-model="${product.model}"]`);
    cards.set(product.model, card);
    wireCard(card, product);
    const previous = previousMessages.get(product.model);
    if (previous) {
      const message = card.querySelector(".form-message");
      message.textContent = previous.text;
      message.className = previous.className;
    }
    if (options.refreshModel === product.model) {
      card.querySelector(".export-preview").src = `${product.png_url}?preview=${Date.now()}`;
    }
  }
}

async function loadStatus(options = {}) {
  try {
    const response = await fetch(`/api/status?time=${Date.now()}`, { cache: "no-store" });
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "无法读取运行状态。");
    }
    setOverallStatus(payload);
    renderProducts(payload.products, options);
    showGlobalMessage("");
  } catch (error) {
    overallStatus.className = "status-pill is-error";
    overallStatus.querySelector(".status-text").textContent = "本地服务异常";
    showGlobalMessage(`无法读取工作台：${error.message}`, true);
  }
}

loadStatus();
