#!/usr/bin/env python3
"""Export Xiaoye poster HTML to verified A5 PDF and PNG artifacts."""

from __future__ import annotations

import hashlib
import json
import os
import signal
import shutil
import struct
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Mapping
from urllib.parse import quote
from urllib.request import Request, urlopen

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parent
DEFAULT_BROWSER_CANDIDATES = (
    Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    Path("/usr/bin/google-chrome"),
    Path("/usr/bin/chromium"),
    Path("/usr/bin/chromium-browser"),
)
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
A5_WIDTH_POINTS = 419.53
A5_HEIGHT_POINTS = 595.28
EXPORT_TIMEOUT_SECONDS = 45
NODE_EXPORT_HELPER = ROOT / "xiaoye_chrome_export.mjs"


class ExportError(Exception):
    """A poster export failure with a precise user-facing step."""

    def __init__(self, step: str, detail: str) -> None:
        self.step = step
        self.detail = detail
        super().__init__(f"{step}失败：{detail}")


@dataclass(frozen=True)
class ArtifactPaths:
    html: Path
    pdf: Path
    png: Path

    def as_dict(self) -> Dict[str, Path]:
        return {"html": self.html, "pdf": self.pdf, "png": self.png}


def paths_for_html(html_path: Path) -> ArtifactPaths:
    return ArtifactPaths(
        html=html_path,
        pdf=html_path.with_suffix(".pdf"),
        png=html_path.with_suffix(".png"),
    )


def browser_candidates() -> Iterable[Path]:
    configured = os.environ.get("XIAOYE_CHROME_PATH", "").strip()
    if configured:
        yield Path(configured)
    for variable in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        base = os.environ.get(variable, "").strip()
        if not base:
            continue
        yield Path(base) / "Google/Chrome/Application/chrome.exe"
        yield Path(base) / "Microsoft/Edge/Application/msedge.exe"
    for command in ("chrome", "chrome.exe", "msedge", "msedge.exe", "chromium", "chromium-browser"):
        resolved = shutil.which(command)
        if resolved:
            yield Path(resolved)
    yield from DEFAULT_BROWSER_CANDIDATES


def find_browser() -> Path:
    for candidate in browser_candidates():
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate
    raise ExportError(
        "浏览器检查",
        "未找到 Google Chrome、Microsoft Edge 或 Chromium；请先确认安装方案",
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _terminate_process(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    if os.name == "nt":
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=2)
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=3)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass


def _create_page_target(port: int, source_url: str) -> str:
    request = Request(
        f"http://127.0.0.1:{port}/json/new?{quote(source_url, safe='')}",
        method="PUT",
    )
    try:
        with urlopen(request, timeout=5) as response:
            payload = json.load(response)
    except Exception as exc:
        raise ExportError("浏览器启动", f"无法创建导出页面：{exc}") from exc
    web_socket_url = payload.get("webSocketDebuggerUrl")
    if not isinstance(web_socket_url, str) or not web_socket_url:
        raise ExportError("浏览器启动", "Chrome 未返回页面调试地址")
    return web_socket_url


def _run_chrome_devtools_export(
    browser: Path,
    source_url: str,
    pdf_path: Path,
    png_path: Path,
    profile_dir: Path,
) -> None:
    arguments = [
        str(browser),
        "--headless=new",
        "--disable-gpu",
        "--disable-extensions",
        "--disable-background-networking",
        "--disable-component-update",
        "--disable-sync",
        "--metrics-recording-only",
        "--no-default-browser-check",
        "--no-first-run",
        "--allow-file-access-from-files",
        "--remote-debugging-port=0",
        f"--user-data-dir={profile_dir}",
        "about:blank",
    ]
    process_options = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if os.name == "nt":
        process_options["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    else:
        process_options["start_new_session"] = True
    process = subprocess.Popen(arguments, **process_options)
    deadline = time.monotonic() + EXPORT_TIMEOUT_SECONDS
    port_file = profile_dir / "DevToolsActivePort"
    try:
        while time.monotonic() < deadline:
            if port_file.is_file():
                lines = port_file.read_text(encoding="utf-8").splitlines()
                if lines and lines[0].isdigit():
                    web_socket_url = _create_page_target(int(lines[0]), source_url)
                    break
            if process.poll() is not None:
                raise ExportError(
                    "浏览器启动",
                    f"Chrome 提前退出，返回码 {process.returncode}",
                )
            time.sleep(0.1)
        else:
            raise ExportError(
                "浏览器启动",
                f"等待 Chrome 超过 {EXPORT_TIMEOUT_SECONDS} 秒",
            )

        try:
            completed = subprocess.run(
                [
                    "node",
                    str(NODE_EXPORT_HELPER),
                    web_socket_url,
                    source_url,
                    str(pdf_path),
                    str(png_path),
                ],
                capture_output=True,
                text=True,
                timeout=EXPORT_TIMEOUT_SECONDS,
            )
        except FileNotFoundError as exc:
            raise ExportError(
                "浏览器导出",
                "未找到现有 Node.js 运行环境，请先确认安装方案",
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise ExportError(
                "浏览器导出",
                f"等待页面导出超过 {EXPORT_TIMEOUT_SECONDS} 秒",
            ) from exc
        if completed.returncode != 0:
            try:
                failure = json.loads(completed.stderr)
            except json.JSONDecodeError:
                failure = {
                    "step": "浏览器导出",
                    "detail": completed.stderr.strip() or "Chrome 导出失败",
                }
            raise ExportError(
                str(failure.get("step") or "浏览器导出"),
                str(failure.get("detail") or "Chrome 导出失败"),
            )
    finally:
        _terminate_process(process)


def _browser_source(rendered_html: str) -> str:
    if "<head>" not in rendered_html or "</head>" not in rendered_html:
        raise ExportError("HTML 核对", "生成内容缺少完整的 <head>")
    with_base = rendered_html.replace(
        "<head>",
        f'<head>\n  <base href="{ROOT.as_uri()}/">',
        1,
    )
    export_style = """
  <style id="xiaoye-png-export-frame">
    @media screen {{
      html, body {{
        width: 148mm !important;
        height: 210mm !important;
        min-height: 0 !important;
        overflow: hidden !important;
        background: transparent !important;
      }}
      body {{ display: block !important; padding: 0 !important; }}
      .poster {{ box-shadow: none !important; zoom: 1 !important; }}
    }}
  </style>
"""
    return with_base.replace("</head>", f"{export_style}</head>", 1)


def _validate_pdf(path: Path, expected_price: str) -> None:
    try:
        reader = PdfReader(path)
    except Exception as exc:
        raise ExportError("PDF 核对", f"文件无法打开：{exc}") from exc
    if len(reader.pages) != 1:
        raise ExportError("PDF 核对", f"应为 1 页，实际为 {len(reader.pages)} 页")
    page = reader.pages[0]
    width = float(page.mediabox.width)
    height = float(page.mediabox.height)
    if abs(width - A5_WIDTH_POINTS) > 3 or abs(height - A5_HEIGHT_POINTS) > 3:
        raise ExportError(
            "PDF 核对",
            f"页面不是 A5 竖版：{width:.1f} × {height:.1f} pt",
        )
    extracted = page.extract_text() or ""
    if expected_price not in extracted:
        raise ExportError("PDF 核对", f"未读取到教学价 {expected_price}")


def _png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        if handle.read(8) != PNG_SIGNATURE:
            raise ExportError("PNG 核对", "文件签名不是 PNG")
        length = struct.unpack(">I", handle.read(4))[0]
        chunk_type = handle.read(4)
        if chunk_type != b"IHDR" or length < 8:
            raise ExportError("PNG 核对", "缺少有效 IHDR 尺寸信息")
        return struct.unpack(">II", handle.read(8))


def _validate_png(path: Path) -> None:
    try:
        width, height = _png_dimensions(path)
    except OSError as exc:
        raise ExportError("PNG 核对", f"文件无法读取：{exc}") from exc
    if width < 1000 or height < 1400:
        raise ExportError(
            "PNG 核对",
            f"分辨率过低：{width} × {height}",
        )
    expected_ratio = 148 / 210
    if abs((width / height) - expected_ratio) > 0.003:
        raise ExportError(
            "PNG 核对",
            f"画面不是 A5 竖版比例：{width} × {height}",
        )


def stage_artifacts(
    rendered_html: str,
    target_html: Path,
    expected_price: str,
    staging_dir: Path,
) -> ArtifactPaths:
    """Create and verify one HTML/PDF/PNG bundle inside staging_dir."""
    browser = find_browser()
    staged = ArtifactPaths(
        html=staging_dir / target_html.name,
        pdf=staging_dir / target_html.with_suffix(".pdf").name,
        png=staging_dir / target_html.with_suffix(".png").name,
    )
    staged.html.write_text(rendered_html, encoding="utf-8")
    browser_source = staging_dir / f".{target_html.stem}-browser-source.html"
    browser_source.write_text(_browser_source(rendered_html), encoding="utf-8")

    _run_chrome_devtools_export(
        browser,
        browser_source.as_uri(),
        staged.pdf,
        staged.png,
        staging_dir / "chrome-pdf-profile",
    )
    _validate_pdf(staged.pdf, expected_price)
    _validate_png(staged.png)
    return staged


def artifact_metadata(paths: Mapping[str, Path]) -> Dict[str, Dict[str, str]]:
    return {
        kind: {"filename": path.name, "sha256": sha256_file(path)}
        for kind, path in paths.items()
    }
