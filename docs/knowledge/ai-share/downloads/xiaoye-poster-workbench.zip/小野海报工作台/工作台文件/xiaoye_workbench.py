#!/usr/bin/env python3
"""Local workbench server for the fictional Xiaoye poster demo."""

from __future__ import annotations

import argparse
import copy
import csv
import json
import os
import re
import shutil
import sys
import tempfile
import threading
import webbrowser
from datetime import datetime
from decimal import Decimal, InvalidOperation
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple
from urllib.parse import urlparse

import generate_xiaoye_posters as generator
import xiaoye_poster_export as exporter


ROOT = Path(__file__).resolve().parent
STATE_PATH = ROOT / "xiaoye-workbench-state.json"
WORKBENCH_FILE = "xiaoye-workbench.html"
PRICE_ROUTE = re.compile(r"^/api/products/(DEMO-(?:300|500|1000))/price$")
MAX_REQUEST_BYTES = 4096


class WorkbenchError(Exception):
    """A user-visible workbench error."""


def now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def file_mtime_iso(path: Path) -> str:
    return datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat(
        timespec="seconds"
    )


def atomic_write_text(path: Path, content: str) -> None:
    existing_mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    with tempfile.NamedTemporaryFile(
        "w",
        encoding="utf-8",
        newline="",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(temporary, existing_mode)
    try:
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    atomic_write_text(path, serialized)


def stage_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def atomic_replace_many(replacements: Mapping[Path, Path]) -> None:
    """Replace several artifacts as one recoverable bundle."""
    if not replacements:
        return
    parent = next(iter(replacements)).parent
    with tempfile.TemporaryDirectory(
        dir=parent,
        prefix=".xiaoye-backup-",
    ) as backup_raw:
        backup_dir = Path(backup_raw)
        backups: Dict[Path, Path] = {}
        absent_targets = set()
        for index, target in enumerate(replacements):
            if target.exists():
                backup = backup_dir / f"{index}-{target.name}"
                shutil.copy2(target, backup)
                backups[target] = backup
            else:
                absent_targets.add(target)

        replaced: List[Path] = []
        try:
            for target, staged in replacements.items():
                os.replace(staged, target)
                replaced.append(target)
        except Exception as exc:
            for target in reversed(replaced):
                backup = backups.get(target)
                if backup and backup.exists():
                    os.replace(backup, target)
                elif target in absent_targets and target.exists():
                    target.unlink()
            raise exporter.ExportError("文件提交", str(exc)) from exc


def canonical_price(raw_value: Any) -> str:
    if isinstance(raw_value, bool):
        raise WorkbenchError("教学价必须是大于 0 的数字。")
    text = str(raw_value).strip()
    if not text:
        raise WorkbenchError("教学价必须是大于 0 的数字。")
    try:
        value = Decimal(text)
    except InvalidOperation as exc:
        raise WorkbenchError("教学价必须是大于 0 的数字。") from exc
    if not value.is_finite() or value <= 0:
        raise WorkbenchError("教学价必须是大于 0 的数字。")
    normalized = format(value, "f")
    if "." in normalized:
        normalized = normalized.rstrip("0").rstrip(".")
    return normalized


class WorkbenchStore:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.started_at = now_iso()
        generator.build_outputs()
        self.state = self._load_or_initialize_state()
        self._bootstrap_artifacts()

    def _read_product_rows(self) -> Tuple[List[str], List[Dict[str, str]]]:
        path = generator.PRODUCTS_CSV
        if not path.is_file():
            raise WorkbenchError(f"缺少产品表：{path.name}")
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fieldnames = reader.fieldnames or []
            missing = [
                field for field in generator.PRODUCT_FIELDS if field not in fieldnames
            ]
            if missing:
                raise WorkbenchError(
                    f"产品表缺少字段：{', '.join(missing)}"
                )
            rows = []
            seen = set()
            for line_number, raw_row in enumerate(reader, start=2):
                row = {key: (value or "").strip() for key, value in raw_row.items()}
                model = row.get("model", "")
                if not model:
                    raise WorkbenchError(f"产品表第 {line_number} 行缺少 model。")
                if model in seen:
                    raise WorkbenchError(f"产品表型号重复：{model}")
                seen.add(model)
                rows.append(row)
        return list(fieldnames), rows

    def _load_or_initialize_state(self) -> Dict[str, Any]:
        _, rows = self._read_product_rows()
        row_map = {row["model"]: row for row in rows}
        if STATE_PATH.exists():
            try:
                state = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise WorkbenchError(
                    f"版本状态文件无法读取：{STATE_PATH.name}"
                ) from exc
            if not isinstance(state, dict) or not isinstance(
                state.get("products"), dict
            ):
                raise WorkbenchError(
                    f"版本状态文件结构无效：{STATE_PATH.name}"
                )
        else:
            state = {"schema_version": 2, "products": {}}

        changed = not STATE_PATH.exists()
        for model, (_, output_path) in generator.LAYOUTS.items():
            if model not in row_map:
                raise WorkbenchError(f"产品表缺少型号：{model}")
            entry = state["products"].get(model)
            if not isinstance(entry, dict):
                if not output_path.is_file():
                    raise WorkbenchError(
                        f"型号 {model} 缺少成功海报：{output_path.name}"
                    )
                state["products"][model] = {
                    "successful_version": 1,
                    "last_success_at": file_mtime_iso(output_path),
                    "last_success_price": row_map[model]["teaching_price_cny"],
                    "last_change": "初始确认版本",
                    "last_attempt_at": file_mtime_iso(output_path),
                    "status": "success",
                    "failure_reason": None,
                    "failure_step": None,
                }
                changed = True
        if state.get("schema_version") != 2:
            state["schema_version"] = 2
            changed = True
        if changed:
            atomic_write_json(STATE_PATH, state)
        return state

    def _artifacts_match_entry(
        self,
        model: str,
        output_path: Path,
        entry: Mapping[str, Any],
    ) -> bool:
        del model
        paths = exporter.paths_for_html(output_path).as_dict()
        metadata = entry.get("artifacts")
        if not isinstance(metadata, dict):
            return False
        for kind, path in paths.items():
            saved = metadata.get(kind)
            if not isinstance(saved, dict) or not path.is_file():
                return False
            if saved.get("filename") != path.name:
                return False
            try:
                if saved.get("sha256") != exporter.sha256_file(path):
                    return False
            except OSError:
                return False
        return True

    def _bootstrap_artifacts(self) -> None:
        """Create missing PDF/PNG sidecars without advancing successful versions."""
        _, rows = self._read_product_rows()
        row_map = {row["model"]: row for row in rows}
        for model, (_, output_path) in generator.LAYOUTS.items():
            entry = self.state["products"][model]
            if self._artifacts_match_entry(model, output_path, entry):
                continue
            expected_price = row_map[model]["teaching_price_cny"]
            attempted_at = now_iso()
            try:
                rendered = output_path.read_text(encoding="utf-8")
                with tempfile.TemporaryDirectory(
                    dir=ROOT,
                    prefix=f".xiaoye-bootstrap-{model.lower()}-",
                ) as staging_raw:
                    staging_dir = Path(staging_raw)
                    staged = exporter.stage_artifacts(
                        rendered,
                        output_path,
                        expected_price,
                        staging_dir,
                    )
                    next_state = copy.deepcopy(self.state)
                    next_entry = next_state["products"][model]
                    next_entry["artifacts"] = exporter.artifact_metadata(
                        staged.as_dict()
                    )
                    next_entry["failure_step"] = None
                    staged_state = staging_dir / STATE_PATH.name
                    stage_json(staged_state, next_state)
                    targets = exporter.paths_for_html(output_path)
                    atomic_replace_many(
                        {
                            targets.pdf: staged.pdf,
                            targets.png: staged.png,
                            STATE_PATH: staged_state,
                        }
                    )
                    self.state = next_state
            except Exception as exc:
                failed_state = copy.deepcopy(self.state)
                failed_entry = failed_state["products"][model]
                reason = self._format_generation_error(exc)
                failed_entry.update(
                    {
                        "last_attempt_at": attempted_at,
                        "status": "failed",
                        "failure_reason": reason,
                        "failure_step": getattr(exc, "step", "初始化导出"),
                    }
                )
                atomic_write_json(STATE_PATH, failed_state)
                self.state = failed_state

    def _write_product_rows(
        self,
        fieldnames: Sequence[str],
        rows: Sequence[Mapping[str, str]],
    ) -> None:
        path = generator.PRODUCTS_CSV
        existing_mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            newline="",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, existing_mode)
        try:
            os.replace(temporary, path)
        finally:
            if temporary.exists():
                temporary.unlink()

    def _products_payload_locked(
        self,
        rows: Sequence[Mapping[str, str]],
    ) -> List[Dict[str, Any]]:
        row_map = {row["model"]: row for row in rows}
        products = []
        for model, (_, output_path) in generator.LAYOUTS.items():
            row = row_map[model]
            entry = self.state["products"][model]
            current_price = row["teaching_price_cny"]
            artifacts_ready = self._artifacts_match_entry(
                model,
                output_path,
                entry,
            )
            in_sync = (
                entry.get("status") == "success"
                and entry.get("last_success_price") == current_price
                and artifacts_ready
            )
            artifact_paths = exporter.paths_for_html(output_path)
            products.append(
                {
                    "model": model,
                    "name": row["name"],
                    "price": current_price,
                    "image_filename": row["image_filename"],
                    "poster_url": f"/{output_path.name}",
                    "pdf_url": f"/{artifact_paths.pdf.name}",
                    "png_url": f"/{artifact_paths.png.name}",
                    "artifacts_ready": artifacts_ready,
                    "successful_version": entry["successful_version"],
                    "last_success_at": entry["last_success_at"],
                    "last_success_price": entry["last_success_price"],
                    "last_change": entry["last_change"],
                    "last_attempt_at": entry["last_attempt_at"],
                    "status": entry["status"],
                    "failure_reason": entry.get("failure_reason"),
                    "failure_step": entry.get("failure_step"),
                    "in_sync": in_sync,
                }
            )
        return products

    def status_payload(self) -> Dict[str, Any]:
        with self.lock:
            _, rows = self._read_product_rows()
            products = self._products_payload_locked(rows)
            failures = [product for product in products if not product["in_sync"]]
            return {
                "service": "running",
                "started_at": self.started_at,
                "export_tool": exporter.find_browser().name,
                "overall_status": "warning" if failures else "success",
                "overall_message": (
                    f"服务运行中 · {len(failures)} 款海报需要处理"
                    if failures
                    else "服务运行中 · 3 款海报与产品表一致"
                ),
                "products": products,
            }

    def save_price(self, model: str, raw_price: Any) -> Tuple[int, Dict[str, Any]]:
        new_price = canonical_price(raw_price)
        with self.lock:
            fieldnames, rows = self._read_product_rows()
            matches = [row for row in rows if row["model"] == model]
            if not matches:
                raise WorkbenchError(f"产品表找不到型号：{model}")
            if len(matches) > 1:
                raise WorkbenchError(f"产品表型号重复：{model}")

            row = matches[0]
            old_price = row["teaching_price_cny"]
            entry = self.state["products"][model]
            needs_retry = (
                entry.get("status") != "success"
                or entry.get("last_success_price") != new_price
                or not self._artifacts_match_entry(
                    model,
                    generator.LAYOUTS[model][1],
                    entry,
                )
            )
            if old_price == new_price and not needs_retry:
                products = self._products_payload_locked(rows)
                return HTTPStatus.OK, {
                    "data_saved": False,
                    "poster_updated": False,
                    "pdf_updated": False,
                    "png_updated": False,
                    "message": "价格未变化，未写入资料，也未更新海报。",
                    "product": next(item for item in products if item["model"] == model),
                }

            data_saved = False
            if old_price != new_price:
                row["teaching_price_cny"] = new_price
                self._write_product_rows(fieldnames, rows)
                data_saved = True

            attempted_at = now_iso()
            try:
                try:
                    outputs = generator.build_outputs()
                except generator.ValidationError as exc:
                    raise exporter.ExportError(
                        "HTML 生成",
                        "；".join(exc.issues),
                    ) from exc
                _, output_path, rendered = outputs[model]
                with tempfile.TemporaryDirectory(
                    dir=ROOT,
                    prefix=f".xiaoye-update-{model.lower()}-",
                ) as staging_raw:
                    staging_dir = Path(staging_raw)
                    staged = exporter.stage_artifacts(
                        rendered,
                        output_path,
                        new_price,
                        staging_dir,
                    )
                    next_state = copy.deepcopy(self.state)
                    next_entry = next_state["products"][model]
                    next_entry.update(
                        {
                            "successful_version": int(
                                next_entry["successful_version"]
                            )
                            + 1,
                            "last_success_at": attempted_at,
                            "last_success_price": new_price,
                            "last_change": (
                                f"教学价：{old_price} → {new_price} 元"
                                if old_price != new_price
                                else f"按当前教学价 {new_price} 元重新生成"
                            ),
                            "last_attempt_at": attempted_at,
                            "status": "success",
                            "failure_reason": None,
                            "failure_step": None,
                            "artifacts": exporter.artifact_metadata(
                                staged.as_dict()
                            ),
                        }
                    )
                    staged_state = staging_dir / STATE_PATH.name
                    stage_json(staged_state, next_state)
                    targets = exporter.paths_for_html(output_path)
                    atomic_replace_many(
                        {
                            targets.html: staged.html,
                            targets.pdf: staged.pdf,
                            targets.png: staged.png,
                            STATE_PATH: staged_state,
                        }
                    )
                    self.state = next_state
            except Exception as exc:
                reason = self._format_generation_error(exc)
                failed_state = copy.deepcopy(self.state)
                failed_entry = failed_state["products"][model]
                failed_entry.update(
                    {
                        "last_attempt_at": attempted_at,
                        "last_change": (
                            f"教学价：{old_price} → {new_price} 元；"
                            "资料已保存，HTML/PDF/PNG 未全部更新"
                            if data_saved
                            else f"按当前教学价 {new_price} 元重试失败"
                        ),
                        "status": "failed",
                        "failure_reason": reason,
                        "failure_step": getattr(exc, "step", "海报更新"),
                    }
                )
                try:
                    atomic_write_json(STATE_PATH, failed_state)
                    self.state = failed_state
                except OSError:
                    pass
                products = self._products_payload_locked(rows)
                return HTTPStatus.INTERNAL_SERVER_ERROR, {
                    "data_saved": data_saved,
                    "poster_updated": False,
                    "pdf_updated": False,
                    "png_updated": False,
                    "message": (
                        f"资料已保存；{reason}。"
                        "上一次成功的 HTML、PDF 和 PNG 已保留。"
                        if data_saved
                        else f"{reason}。上一次成功的 HTML、PDF 和 PNG 已保留。"
                    ),
                    "product": next(item for item in products if item["model"] == model),
                }

            products = self._products_payload_locked(rows)
            return HTTPStatus.OK, {
                "data_saved": data_saved,
                "poster_updated": True,
                "pdf_updated": True,
                "png_updated": True,
                "message": (
                    "资料已保存；HTML、PDF 和 PNG 已更新并核对通过。"
                    if data_saved
                    else "资料未变；HTML、PDF 和 PNG 已重新生成并核对通过。"
                ),
                "product": next(item for item in products if item["model"] == model),
            }

    @staticmethod
    def _format_generation_error(exc: Exception) -> str:
        if isinstance(exc, exporter.ExportError):
            return str(exc)
        if isinstance(exc, generator.ValidationError):
            return "；".join(exc.issues)
        if isinstance(exc, WorkbenchError):
            return str(exc)
        return f"{type(exc).__name__}: {exc}"


class WorkbenchHandler(SimpleHTTPRequestHandler):
    server_version = "XiaoyeWorkbench/1.0"

    @property
    def store(self) -> WorkbenchStore:
        return self.server.store  # type: ignore[attr-defined]

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/api/status":
            try:
                self._send_json(HTTPStatus.OK, self.store.status_payload())
            except Exception as exc:
                self._send_json(
                    HTTPStatus.INTERNAL_SERVER_ERROR,
                    {"error": WorkbenchStore._format_generation_error(exc)},
                )
            return
        if path in {"/", "/workbench"}:
            self.path = f"/{WORKBENCH_FILE}"
        super().do_GET()

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        match = PRICE_ROUTE.fullmatch(path)
        if not match:
            self._send_json(HTTPStatus.NOT_FOUND, {"error": "接口不存在。"})
            return
        length_text = self.headers.get("Content-Length", "0")
        try:
            length = int(length_text)
        except ValueError:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": "请求长度无效。"})
            return
        if length <= 0 or length > MAX_REQUEST_BYTES:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": "请求内容无效。"})
            return
        try:
            body = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": "请求不是有效 JSON。"})
            return
        if not isinstance(body, dict) or "price" not in body:
            self._send_json(HTTPStatus.BAD_REQUEST, {"error": "缺少 price。"})
            return

        try:
            status, payload = self.store.save_price(match.group(1), body["price"])
            self._send_json(status, payload)
        except WorkbenchError as exc:
            self._send_json(
                HTTPStatus.BAD_REQUEST,
                {
                    "data_saved": False,
                    "poster_updated": False,
                    "pdf_updated": False,
                    "png_updated": False,
                    "error": str(exc),
                },
            )
        except Exception as exc:
            self._send_json(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {
                    "data_saved": False,
                    "poster_updated": False,
                    "pdf_updated": False,
                    "png_updated": False,
                    "error": WorkbenchStore._format_generation_error(exc),
                },
            )

    def _send_json(self, status: int, payload: Mapping[str, Any]) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def log_message(self, format_string: str, *args: Any) -> None:
        sys.stdout.write(
            f"[{datetime.now().astimezone().strftime('%H:%M:%S')}] "
            f"{format_string % args}\n"
        )
        sys.stdout.flush()


class WorkbenchServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        server_address: Tuple[str, int],
        handler_class: Any,
        store: WorkbenchStore,
    ) -> None:
        super().__init__(server_address, handler_class)
        self.store = store


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="启动小野海报本地工作台。")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=62100)
    parser.add_argument(
        "--open",
        action="store_true",
        help="启动后使用系统默认浏览器打开工作台。",
    )
    return parser.parse_args(list(argv))


def main(argv: Iterable[str] = ()) -> int:
    args = parse_args(argv)
    if args.host not in {"127.0.0.1", "localhost"}:
        print("启动失败：工作台只允许绑定本机 127.0.0.1。", file=sys.stderr)
        return 2
    try:
        store = WorkbenchStore()
        handler = partial(WorkbenchHandler, directory=str(ROOT))
        server = WorkbenchServer(("127.0.0.1", args.port), handler, store)
    except (OSError, WorkbenchError, generator.ValidationError) as exc:
        reason = WorkbenchStore._format_generation_error(exc)
        print(f"启动失败：{reason}", file=sys.stderr)
        return 2

    url = f"http://127.0.0.1:{args.port}/workbench"
    print(f"小野海报工作台已启动：{url}")
    print("用完后回到此终端按 Control-C 停止服务。")
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n正在停止工作台……")
    finally:
        server.server_close()
    print("工作台已停止。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
