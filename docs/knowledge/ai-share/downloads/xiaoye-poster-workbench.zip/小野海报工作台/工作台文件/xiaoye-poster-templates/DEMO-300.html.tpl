<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="{{name}} 露营市集 A5 教学海报">
  <title>{{name}}｜A5 露营市集海报</title>
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%231c4638'/%3E%3Cpath d='M14 44 27 20l7 13 5-9 11 20Z' fill='%23f4e9cd'/%3E%3Ccircle cx='47' cy='17' r='6' fill='%23e88945'/%3E%3C/svg%3E">
  <link rel="stylesheet" href="xiaoye-poster-common.css">
  <link rel="stylesheet" href="xiaoye-300-poster.css">
</head>
<body>
  <main class="poster poster-300" aria-label="{{name}} 露营市集 A5 产品海报">
    <header class="topline">
      <p class="eyebrow">周末露营搭子</p>
      <p class="model" aria-label="型号 {{model}}">{{model}}</p>
    </header>

    <section class="hero" aria-labelledby="poster-title">
      <!-- 主标题：每一行都可独立修改 -->
      <h1 class="headline" id="poster-title">
        <span class="headline-line">{{title_line1}}</span>
        <span class="headline-line">{{title_line2}}<span class="headline-mark">{{title_mark}}</span></span>
      </h1>

      <!-- 产品介绍：引导语与正文分开，方便独立修改 -->
      <p class="intro">
        <span class="intro-lead">{{intro_lead}}</span>
        <span class="intro-detail">{{intro_detail}}</span>
      </p>

      <!-- 产品名与数字分开排版 -->
      <div class="name-badge" aria-label="产品名 {{name}}">
        <span class="product-name">{{product_prefix}}</span>
        <span class="product-number">{{product_number}}</span>
      </div>

      <div class="product-stage">
        <img class="poster-image product-image" src="{{image_filename}}" alt="{{name}} 户外电源教学产品插画">
      </div>
    </section>

    <!-- 参数：标签、数字、单位分别独立，方便修改 -->
    <section class="specs" aria-label="产品参数">
      <article class="spec-card">
        <span class="spec-label">电池容量</span>
        <span class="spec-value-row">
          <span class="spec-value">{{capacity_wh}}</span>
          <span class="spec-unit">Wh</span>
        </span>
      </article>
      <article class="spec-card">
        <span class="spec-label">额定输出</span>
        <span class="spec-value-row">
          <span class="spec-value">{{rated_output_w}}</span>
          <span class="spec-unit">W</span>
        </span>
      </article>
      <article class="spec-card">
        <span class="spec-label">轻巧重量</span>
        <span class="spec-value-row">
          <span class="spec-value">{{weight_kg}}</span>
          <span class="spec-unit">kg</span>
        </span>
      </article>
    </section>

    <!-- 价格：说明、币种、数字、单位分别独立，方便修改 -->
    <section class="price-row" aria-label="教学价格 {{teaching_price_cny}} 元">
      <div class="price-copy">
        <span class="price-kicker">露营市集 · 教学价</span>
        <span class="price-note">轻一点出发，周末刚刚好</span>
      </div>
      <div class="price">
        <span class="price-currency">¥</span>
        <span class="price-value">{{teaching_price_cny}}</span>
        <span class="price-unit">元</span>
      </div>
    </section>

    <footer class="footer">教学虚构资料</footer>
  </main>
</body>
</html>
